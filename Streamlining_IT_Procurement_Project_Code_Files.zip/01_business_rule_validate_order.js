// Business Rule
// Name: Validate Standard Laptop Order
// Table: u_laptop_order
// When: before
// Insert: true
// Update: true

(function executeRule(current, previous /*null when async*/) {

    var quantity = parseInt(current.u_quantity, 10);

    if (isNaN(quantity) || quantity < 1) {
        gs.addErrorMessage('Laptop quantity must be at least 1.');
        current.setAbortAction(true);
        return;
    }

    if (quantity > 10) {
        gs.addErrorMessage('For this automated standard order, quantity cannot exceed 10.');
        current.setAbortAction(true);
        return;
    }

    if (!current.u_laptop_model) {
        gs.addErrorMessage('Laptop model is required.');
        current.setAbortAction(true);
        return;
    }

    if (!current.u_requested_for) {
        gs.addErrorMessage('Requested for user is required.');
        current.setAbortAction(true);
        return;
    }

    if (current.u_quantity.changes() || current.u_laptop_model.changes()) {
        current.u_status = 'pending_approval';
    }

})(current, previous);
