// Script Include
// Name: LaptopProcurementUtils
// Client callable: false

var LaptopProcurementUtils = Class.create();
LaptopProcurementUtils.prototype = {

    initialize: function() {},

    calculateTotal: function(model, quantity) {
        quantity = parseInt(quantity, 10) || 0;

        var prices = {
            'Standard Laptop': 50000,
            'Business Laptop': 65000,
            'Developer Laptop': 85000
        };

        var unitPrice = prices[model] || 0;
        return unitPrice * quantity;
    },

    getManager: function(userSysId) {
        if (!userSysId)
            return '';

        var user = new GlideRecord('sys_user');
        if (user.get(userSysId) && user.manager)
            return user.manager.toString();

        return '';
    },

    generateProcurementNumber: function() {
        return 'LAP-' + new GlideDateTime().getNumericValue();
    },

    type: 'LaptopProcurementUtils'
};
