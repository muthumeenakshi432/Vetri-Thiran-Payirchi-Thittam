// Business Rule
// Name: Calculate Laptop Order Cost
// Table: u_laptop_order
// When: before
// Insert: true
// Update: true

(function executeRule(current, previous) {

    var util = new LaptopProcurementUtils();
    var total = util.calculateTotal(
        current.u_laptop_model.toString(),
        current.u_quantity.toString()
    );

    current.u_total_cost = total;

})(current, previous);
