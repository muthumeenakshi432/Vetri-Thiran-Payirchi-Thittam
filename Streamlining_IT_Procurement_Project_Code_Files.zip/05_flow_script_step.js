// Flow Designer Script step
// Purpose: Return manager sys_id for the requester.

(function() {
    var util = new LaptopProcurementUtils();
    var requester = fd_data.trigger.current.u_requested_for.toString();

    if (!requester) {
        return '';
    }

    return util.getManager(requester);
})();
