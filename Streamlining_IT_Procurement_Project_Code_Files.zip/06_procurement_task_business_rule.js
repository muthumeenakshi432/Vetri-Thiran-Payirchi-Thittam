// Business Rule
// Table: u_laptop_procurement_task
// When: after
// Update: true
// Condition: Status changes to Closed

(function executeRule(current, previous) {

    if (!current.u_status.changesTo('closed')) {
        return;
    }

    if (!current.u_order) {
        return;
    }

    var order = new GlideRecord('u_laptop_order');

    if (order.get(current.u_order)) {
        order.u_status = 'completed';
        order.update();
    }

})(current, previous);
