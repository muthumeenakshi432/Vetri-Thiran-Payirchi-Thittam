STREAMLINING IT PROCUREMENT: AUTOMATING STANDARD LAPTOP ORDERS WITH FLOW DESIGNER

Platform: ServiceNow
Project type: Flow Designer based IT Procurement Automation

IMPORTANT:
The uploaded project document provides the project title and college/team details, but it does not contain source code or technical implementation details. The files in this pack are a proposed working project structure based on the project title.

IMPLEMENTATION OVERVIEW
1. Create a custom table: u_laptop_order
2. Create fields:
   u_requested_for        Reference -> User [sys_user]
   u_laptop_model        String
   u_quantity             Integer
   u_department           String
   u_reason               String
   u_total_cost           Currency
   u_status               Choice
   u_manager              Reference -> User [sys_user]
   u_approval_notes       String
   u_procurement_number   String
3. Create a Flow Designer flow:
   Trigger: record created on u_laptop_order
   Actions:
   - Validate order
   - Determine manager
   - Ask for approval
   - If approved: create procurement task
   - Send confirmation
   - If rejected: update order and notify requester
4. Add the Business Rule and Script Include from this folder.
5. Test Approved, Rejected, Invalid Quantity and Missing Manager cases.

Suggested status choices:
Draft
Pending Approval
Approved
Rejected
Procurement
Completed
Cancelled
